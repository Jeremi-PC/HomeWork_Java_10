package org.example.exception;

public class CheckOutputFileException extends Exception{
    public CheckOutputFileException(String message) {
        super(message);
    }
}
