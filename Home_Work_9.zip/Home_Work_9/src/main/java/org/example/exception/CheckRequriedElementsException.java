package org.example.exception;

public class CheckRequriedElementsException extends RuntimeException{
    public CheckRequriedElementsException(String message) {
        super(message);
    }
}
