package org.example.exception;

public class CheckValidValuesException extends  RuntimeException{
    public CheckValidValuesException(String message) {
        super(message);
    }
}
